<?php $__env->startSection('contenido'); ?>
	<div class="row">

				<?php foreach($per as $sa): ?>
				
				<h1><?php echo e($sa->nom); ?></h1>
				<table class="table table-striped table-bordered table-condensed table-hover">
					<thead>
						<th>Periodo</th>
						<th>nose</th>
					</thead>
					<tbody>
						

						<?php foreach($datoss[0] as $mm): ?>

						<?php if($sa->nom === $mm->usu): ?>
						<tr>
							<?php if($mm->mes == 1): ?>
							
							    <td>Enero</td>
							    
							<?php elseif($mm->mes == 2): ?>
							    <td>Febrero</td>
							<?php elseif($mm->mes == 3): ?>
							    <td>Marzo</td>
							 <?php elseif($mm->mes == 4): ?>
							 	<td>Abril</td>
							 <?php elseif($mm->mes == 5): ?>
							 	<td>Mayo</td>
							  <?php elseif($mm->mes == 6): ?>
							  <td>Junio</td>
							   <?php elseif($mm->mes == 7): ?>
							    <td>Julio</td>
							    <?php elseif($mm->mes == 8): ?>
							    <td>Agosto</td>
							     <?php elseif($mm->mes == 9): ?>
							        <td>Septiembre</td>
							      <?php elseif($mm->mes == 10): ?>
							      <td>Octubre</td>
							       <?php elseif($mm->mes == 11): ?>
							       <td>Noviembre</td>
							        <?php elseif($mm->mes == 12): ?>
							        <td>Diciembre</td>


							<?php endif; ?>	    
							
							<td>
								<?php echo e($mm->receitaLiquida); ?>

							</td>
							<td>
								<td><?php echo e($datoss[1][0]->plata); ?></td>
							</td>
							
							
						</tr>

						<?php endif; ?>
						

						<?php endforeach; ?>
						<?php foreach($toti as $to): ?>
						<?php if($sa->nom == $to->per): ?>
						<tr> <td></td><td><h6><?php echo e($to->total); ?> </h6> </td><td></td></tr>
						<?php endif; ?>	 

						<?php endforeach; ?>
					</tbody>
					

				</table>
				<?php endforeach; ?>
				
		
	</div>
<?php $__env->stopSection(); ?>
					

<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>