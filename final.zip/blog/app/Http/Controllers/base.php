<?php

namespace prueba1\Http\Controllers;

use Illuminate\Http\Request;

use prueba1\Http\Requests;
use prueba1\CaoUsuario;
use Illuminate\Support\Facades\Redirect;
use prueba1\http\Requests\usuarioBase;
use DB;
class base extends Controller
{
    //
    public function __constructor(){

    }
    public function index(Request $request)	
    {
    	if ($request) {
    		$query=trim($request->get('searchText'));
    		$consulta=DB::table('cao_usuario')

    		->join('permissao_sistema','permissao_sistema.co_usuario','=','cao_usuario.co_usuario')
    		->where([
		    		['permissao_sistema.co_sistema', '=', '1'],
		    		['in_ativo', '=', 'S'],
				])
    		->whereIn('co_tipo_usuario', [0, 1, 2])
    		->select('cao_usuario.*')
    		
    		->get()
    		;
    		return view('base.usuario.index',["usuar"=>$consulta,"searchText"=>$query]);

    	} else {
    		# code...
    	}
    	
    }
    public function create()	
    {	
    	return view("base.usuario.create");

    }
    public function prueba()	
    {	
    	

    }
    
    public function show()	
    {

    }
    public function desde(Request $request){

		$x = $request->get('hum') ;
        $desde =$request->get('desde');
        $hasta =$request->get('hasta');
    	$y="";
    	foreach ($x as $key => $value) {
    		if ($key==0) {
    				$y=$y."'".$value."'";
    			} else {
    				$y=$y.','."'".$value."'";
    			}
    				
    	}
        $con3 =DB::select("SELECT sum(fa.valor)  as familia,ROUND(sum((fa.valor-((fa.valor*fa.`total_imp_inc`)/100))),2) as total, ca.co_usuario as per, fa.data_emissao FROM cao_fatura as fa join cao_os as ca on fa.co_os = ca.co_os WHERE ca.co_usuario in(".$y.") AND fa.data_emissao >= '".$desde."' AND fa.data_emissao <= '".$hasta."' GROUP by ca.co_usuario ORDER by ca.co_usuario ASC");
        $con2=DB::select("SELECT ca.co_usuario as nom FROM cao_fatura as fa join cao_os as ca on fa.co_os = ca.co_os WHERE ca.co_usuario in(".$y.") AND fa.data_emissao >= '".$desde."' AND fa.data_emissao <= '".$hasta."' GROUP by ca.co_usuario ");
        $con1=DB::select("SELECT ROUND(sum((fa.valor-((fa.valor*fa.`total_imp_inc`)/100))),2)as receitaLiquida , ca.co_usuario as usu, MONTH(fa.data_emissao) as mes , sala.brut_salario,ROUND(sum(((fa.valor-(fa.valor*fa.`total_imp_inc`)/100)* fa.comissao_cn)/100),2) as impuesto FROM cao_fatura as fa join cao_os as ca on fa.co_os = ca.co_os join cao_salario as sala on ca.co_usuario = sala.co_usuario WHERE ca.co_usuario in(".$y.") AND fa.data_emissao >= '".$desde."' AND fa.data_emissao <= '".$hasta."' GROUP by MONTH(fa.data_emissao),ca.co_usuario ORDER by ca.co_usuario ASC, MONTH(fa.data_emissao)");
        $ver = array($con1,$con2,$con3);
        
        

		return response()->json($ver);
    }
    public function gra(Request $request)	
    {   
        $x = $request->get('hum') ;
        $desde =$request->get('desde');
        $hasta =$request->get('hasta');
        $y="";
        foreach ($x as $key => $value) {
            if ($key==0) {
                    $y=$y."'".$value."'";
                } else {
                    $y=$y.','."'".$value."'";
                }
                    

        }
        $con1=DB::select("SELECT ca.co_usuario as nom FROM cao_fatura as fa join cao_os as ca on fa.co_os = ca.co_os WHERE ca.co_usuario in(".$y.") AND fa.data_emissao >= '".$desde."' AND fa.data_emissao <= '".$hasta."' GROUP by ca.co_usuario ");
        $con = DB::select("SELECT sum(fa.valor)  as familia,ROUND(sum((fa.valor-((fa.valor*fa.`total_imp_inc`)/100))),2)as receitaLiquida , ca.co_usuario as usu, MONTH(fa.data_emissao) as mes FROM cao_fatura as fa join cao_os as ca on fa.co_os = ca.co_os WHERE ca.co_usuario in(".$y.") AND fa.data_emissao >= '".$desde."' AND fa.data_emissao <= '".$hasta."' GROUP by MONTH(fa.data_emissao),ca.co_usuario ORDER by ca.co_usuario ASC, MONTH(fa.data_emissao)");
        $gg=DB::select("SELECT sala.brut_salario, ca.co_usuario  FROM cao_fatura as fa join cao_os as ca on fa.co_os = ca.co_os join cao_salario as sala on ca.co_usuario = sala.co_usuario WHERE ca.co_usuario in(".$y.") AND fa.data_emissao >= '".$desde."' AND fa.data_emissao <= '".$hasta."' GROUP BY ca.co_usuario ORDER by ca.co_usuario ASC");
        $ver = array($con,$con1,$gg);
        return response()->json($ver);

    }
    public function update()	
    {

    }
    public function destroy()	
    {

    }
}
