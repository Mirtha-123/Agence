<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.css">
         
    <!-- Compiled and minified JavaScript -->
   
        <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">


        <style>
            html, body {
                height: 100%;
                margin: 0;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                display: table;
                font-weight: 100;
                
            }

            .container {
                
                display: table-cell;
               
            }

            .content {
                
                display: inline-block;
            }

            .title {
                font-size: 50px;
               color: white;
                
                height: 10%;
               padding-top: 10px;
               text-align: left;
               padding-left: 10px;
               
            }
            .cont{
                margin-top: 5%;
                text-align: center;
                padding-left: 10%;
                 padding-right:  10%;
            }
            #graf{
              padding-top: 20px;
              margin-top: 20px;
            }
            .btn{
              margin-top: 5px;
            }
            #ti{
              padding-left: 30px;

            }
        </style>
    </head>
    <body>
        <div class="container">
            
             <nav>
    <div class="nav-wrapper blue darken-4">
      <a href="#" id="ti" class="brand-logo title"> Agence</a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="sass.html">Agence</a></li>
        <li><a href="badges.html">Projetos</a></li>
        <li><a href="collapsible.html">Administrativo</a></li>
      </ul>
    </div>
  </nav>
                
                <div class="cont">
                  <a href="/base/usuario"><h3>Performace Comercial</h3></a>
                    <?php echo $__env->yieldContent('contenido'); ?>
                </div>
            
        </div>
        <script
  src="https://code.jquery.com/jquery-3.3.1.js"
  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
  crossorigin="anonymous"></script>
 
 <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.bundle.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.js"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
         <script src="<?php echo e(asset('index.js')); ?>"></script>

    </body>
</html>
