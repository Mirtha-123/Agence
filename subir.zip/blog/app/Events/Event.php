<?php

namespace prueba1\Events;

abstract class Event
{
    //
}
