@extends ('welcome')
@section ('contenido')
	<div class="row">
		<h1>Con Desem Consultor	</h1>
		<div class="container">
			<div class="col m2">
				<span>Desde</span>
				<input type="text" class="datepicker" id="desde">
				
			</div>
			<div class="col m2">
				<span>Hasta</span>
				<input type="text" class="datepicker" id="hasta">
			</div>
		
			<div class="col m6">
				<div class="input-field">
			    <select multiple name="personas[]" id="hum">
			      @foreach ($usuar as $usu)
			      <option name="{{$usu->co_usuario}}" value="{{$usu->co_usuario}}" >{{$usu->co_usuario}} </option>
			      
			      @endforeach
			    </select>
			    <label>Materialize Multiple Select</label>
			  </div>
			</div>	
			<div class="col m2">
				<button type="button" id="boton1" class="waves-effect waves-green btn btn-primary pink darken-2">Relatorio</button>
				<button type="button" id="boton2" class="waves-effect waves-green btn btn-primary  blue darken-1 ">Grafico</button>
				<button type="button" id="boton3" class="waves-effect waves-green btn btn-primary">Pizza</button>
			</div>	
			
		
			<div class="col s12 m6 l6">

				<div id="bo"> 
					
				</div>
				
				
			</div>
			<div class="col s12 m6 l6">
				
				<div id="graf"> 
					
				</div>
				
				
			</div>

		</div>
		
	</div>
@endsection