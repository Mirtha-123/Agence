 document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('select');
    var instances = M.FormSelect.init(elems, options);
  });

  // Or with jQuery

  $(document).ready(function(){


    $('.cont').addClass('animated fadeIn');







    $('select').formSelect();
    $('.datepicker').datepicker({
       format: 'yyyy/mm/dd',
    });
    $("#boton2").on('click',(u)=>{
      
      if ($("#desde").val()!="") {
        if ($("#hasta").val()!="") {
      var x ={
        hum:$("#hum").val(),
        desde:$("#desde").val(),            
        hasta:$("#hasta").val()
      } 
      console.log(x)
      u.preventDefault();
      $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                  }
              });
      jQuery.ajax({
                  url: "/base/grafico",
                  method: 'get',
                  data: x,
                  success: function(result){
                    $("#graf").empty()
                    $("#graf").append('<canvas id="myChart" width="400" height="400"></canvas>')
                    $("#graf").addClass('animated fadeIn')
                    var nombres=[]
                    var datos=[]
                    var origen={}
                    var meses=[]
                    
                    var d=[]
                    var ayuda=[]
                    for (var i = result[1].length - 1; i >= 0; i--) {
                      nombres.push(result[1][i].nom)
                    }
                    for (var k = nombres.length - 1; k >= 0; k--) {
                      d=[]
                      for (var l = result[0].length - 1; l >= 0; l--) {
                       
                        if (result[0][l].usu==nombres[k]) {
                          d.push(result[0][l].receitaLiquida)
                         
                        }
                      }
                      ayuda.push(d)
                    }
                    for (var j = result[0].length - 1; j >= 0; j--) {
                      switch(result[0][j].mes){
                        case "1":
                            meses.push('Enero')
                            break;
                        case "2":
                            meses.push('Febrero')

                            break;
                            case "3":
                            meses.push('Marzo')

                            break;
                            case "4":
                           meses.push('Abril')

                            break;
                            case "5":
                            meses.push('Mayo')

                            break;
                            case "6":
                            meses.push('Junio')

                            break;
                            case "7":
                           meses.push('Julio')

                            break;
                            case "8":
                           meses.push('Agosto')

                            break;
                            case "9":
                            meses.push('Septiembre')

                            break;
                            case "10":
                            meses.push('Octubre')

                            break;
                             case "11":
                            meses.push('Noviembre')

                            break;
                            case "12":
                            meses.push('Diciembre')

                            break;
                        default:
                            // code block
                      }
                    }

                    let sinRepetidos = meses.filter(function (valor, indiceActual, arreglo) {
                      let indiceAlBuscar = arreglo.indexOf(valor);
                      if (indiceActual === indiceAlBuscar) {
                        return true;
                      } else {
                        return false;
                      }
                    });
                     console.log(sinRepetidos)
                     for (var y = nombres.length - 1; y >= 0; y--) {
                       var color = random_rgba();
                       
                       var k = new recurso(nombres[y],ayuda[y],color,color,"1")
                       
                       datos.push(k)
                       console.log(k)
                     }
                      console.log(datos)
                      

                    
                      var ctx = document.getElementById("myChart").getContext('2d');
                      
                      var myChart = new Chart(ctx, {
                          type: 'bar',
                          data: {
                              labels: sinRepetidos,
                              datasets:datos
                          },
                          options: {
                              scales: {
                                  yAxes: [{
                                      ticks: {
                                          beginAtZero:true
                                      }
                                  }]
                              }
                          }
                      });















                      
                    
                    // console.log(result)
                  }});
  }else{
    alert("Rellene todos los campos porfavor")
  }
}else{
  alert("Rellene todos los campos")
}
    })
 $("#boton3").on('click',(e)=>{
    if ($("#desde").val()!="") {
        if ($("#hasta").val()!="") {
     var x ={
        hum:$("#hum").val(),
        desde:$("#desde").val(),            
        hasta:$("#hasta").val()
      } 
     e.preventDefault();
               $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                  }
              });
      jQuery.ajax({
                  url: "/base/pizza",
                  method: 'get',
                  data: x,
                  success: function(result){
                    $("#graf").empty()
                    $("#graf").append('<canvas id="myChart" width="400" height="400"></canvas>')
                    $("#graf").addClass('animated fadeIn')
                    var nombres=[]
                    var datos=[]
                    var origen={}
                    var meses=[]
                    
                    var d=[]
                    var ayuda=[]
                    for (var i = result[1].length - 1; i >= 0; i--) {
                      nombres.push(result[1][i].nom)
                    }
                    for (var k = nombres.length - 1; k >= 0; k--) {
                      
                      var m=0
                      for (var l = result[0].length - 1; l >= 0; l--) {
                       
                        if (result[0][l].usu==nombres[k]) {
                          m=m+parseFloat(result[0][l].receitaLiquida)
                          dosDecimales(m)
                        }
                      }
                      ayuda.push(m)
                    }
                    console.log(nombres,ayuda)
                       var ctx = document.getElementById("myChart").getContext('2d');
                      
                      var myChart = new Chart(ctx, {
                          type: 'doughnut',
                          data: {
                              labels: nombres,
                              datasets:[{
                                data:ayuda,
                                backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
                              } ]
                          },
                          options: {
                              scales: {
                                  yAxes: [{
                                      ticks: {
                                          beginAtZero:true
                                      }
                                  }]
                              }
                          }
                      });

                     console.log(result)
                  }});
    }else{
      alert("Relleno todos los campos porfavor")
    }
  }else{
      alert("Relleno todos los campos porfavor")
    }
 })
    $("#boton1").on('click',(e)=>{
      if ($("#desde").val()!="") {
        if ($("#hasta").val()!="") {
    	var x ={
    		hum:$("#hum").val(),
        desde:$("#desde").val(),            
        hasta:$("#hasta").val()
    	} 
    	 e.preventDefault();
               $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                  }
              });
    	jQuery.ajax({
                  url: "/base/traer",
                  method: 'get',
                  data: x,
                  success: function(result){
                    $("#bo").empty()
                    for (var i = result[1].length - 1; i >= 0; i--) {
                       var p = result[1][i].nom.split('.')
                       var b = String(p[0]+p[1])
                       $("#bo").addClass('animated fadeIn')
                       $("#bo").append(`<h3>${result[1][i].nom}</h3>
                          <table  class="table table-striped table-bordered table-condensed table-hover">
                          <thead>
                            <th>Periodo</th>
                            <th>Receita Líquida</th>
                            <th>Custo Fixo</th>
                            <th>Comissão</th>
                            <th>Lucro</th>
                          </thead>
                          <tbody id="${b}">
                           
                          </tbody>
                          

                        </table>
                         `)
                    }
                    for (var i = result[0].length - 1; i >= 0; i--) {
                      var z = result[0][i].usu.split('.')

                      var t = String(z[0]+z[1])
                       var x = result[0][i].mes
                       var y =""
                       switch (x){
                          case "1":
                            y="Enero"
                            break;
                          case "2":
                            y="Febrero"
                            break;
                            case "3":
                            y="Marzo"
                            break;
                            case "4":
                            y="Abril"
                            break;
                            case "5":
                            y="Mayo"
                            break;
                            case "6":
                            y="Junio"
                            break;
                            case "7":
                            y="Julio"
                            break;
                            case "8":
                           y="Agosto"
                            break;
                            case "9":
                            y="Septiembre"
                            break;
                            case "10":
                            y="Octubre"
                            break;
                             case "11":
                            y="Noviembre"
                            break;
                            case "12":
                            y="Diciembre"
                            break;
                          default:
                            y="error"
                        }

                      $(`#${t}`).prepend(`
                        <tr>
                          <td>${y}</td>
                          <td>${result[0][i].receitaLiquida}</td>
                          <td>${result[0][i].brut_salario}</td>
                          <td>${result[0][i].impuesto}</td>
                          <td>${dosDecimales((parseFloat(result[0][i].receitaLiquida)-(parseFloat(result[0][i].brut_salario)+parseFloat(result[0][i].impuesto))))}</td>
                        </tr>

                        `)

                    }
                     for (var i = result[2].length - 1; i >= 0; i--) {
                      var e = result[2][i].per.split('.')
                      var u = String(e[0]+e[1])
                      var k =0
                      var er=0
                      var as=0.0
                      for (var j = result[0].length - 1; j >= 0; j--) {
                        if (result[0][j].usu==result[2][i].per) {
                          k=k+parseFloat(result[0][j].brut_salario)
                          er=er + parseFloat(result[0][j].impuesto)
                          pr= parseFloat(result[0][j].brut_salario)+parseFloat(result[0][j].impuesto)
                          op= parseFloat(result[0][j].receitaLiquida)-pr
                          as =as +op
                        }
                      }
                      $(`#${u} tr`).last().after(`
                        <tr>
                          <td></td>
                          <td>${result[2][i].total}</td>
                          <td>${k}</td>
                          <td>${dosDecimales(er)}</td>
                          <td>${dosDecimales(as)}</td>
                        </tr>
                        `)
                    }
                    

                     console.log(result)
                  }});
}else{
  alert("Rellene todos los campos porfavor")
}
}else{
  alert("Rellene todos los campos porfavor")
}
    })
  });
function random_rgba() {
    var o = Math.round, r = Math.random, s = 255;
    return 'rgba(' + o(r()*s) + ',' + o(r()*s) + ',' + o(r()*s) + ',' + r().toFixed(1) + ')';
}
function recurso(label,data,backgroundColor,borderColor,bordersito){
  this.label =label
  this.data=data
  this.backgroundColor=backgroundColor
  this.borderColor=borderColor
  this.borderWith=bordersito
}
function dosDecimales(n) {
  let t=n.toString();
  let regex=/(\d*.\d{0,2})/;
  return t.match(regex)[0];
}
            
