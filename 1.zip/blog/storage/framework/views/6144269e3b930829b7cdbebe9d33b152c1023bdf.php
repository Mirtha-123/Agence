<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<h1>Con Desem Consultor	</h1>
		<div class="container">
			<div class="col m2">
				<span>Desde</span>
				<input type="text" class="datepicker" id="desde">
				
			</div>
			<div class="col m2">
				<span>Hasta</span>
				<input type="text" class="datepicker" id="hasta">
			</div>
		
			<div class="col m6">
				<div class="input-field">
			    <select multiple name="personas[]" id="hum">
			      <?php foreach($usuar as $usu): ?>
			      <option name="<?php echo e($usu->co_usuario); ?>" value="<?php echo e($usu->co_usuario); ?>" ><?php echo e($usu->co_usuario); ?> </option>
			      
			      <?php endforeach; ?>
			    </select>
			    <label>Materialize Multiple Select</label>
			  </div>
			</div>	
			<div class="col m2">
				<button type="button" id="boton1" class="waves-effect waves-green btn btn-primary pink darken-2">Relatorio</button>
				<button type="button" id="boton2" class="waves-effect waves-green btn btn-primary  blue darken-1 ">Grafico</button>
				<button type="button" id="boton3" class="waves-effect waves-green btn btn-primary">Pizza</button>
			</div>	
			
		
			<div class="col s12 m6 l6">

				<div id="bo"> 
					
				</div>
				
				
			</div>
			<div class="col s12 m6 l6">

				<div id="graf"> 
					
				</div>
				
				
			</div>

		</div>
		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>