@extends ('welcome')
@section ('contenido')
	<div class="row">

				@foreach ($per as $sa)
				
				<h1>{{$sa->nom}}</h1>
				<table class="table table-striped table-bordered table-condensed table-hover">
					<thead>
						<th>Periodo</th>
						<th>nose</th>
					</thead>
					<tbody>
						

						@foreach ($datoss[0] as $mm)

						@if ($sa->nom === $mm->usu)
						<tr>
							@if ($mm->mes == 1)
							
							    <td>Enero</td>
							    
							@elseif ($mm->mes == 2)
							    <td>Febrero</td>
							@elseif ($mm->mes == 3)
							    <td>Marzo</td>
							 @elseif ($mm->mes == 4)
							 	<td>Abril</td>
							 @elseif ($mm->mes == 5)
							 	<td>Mayo</td>
							  @elseif ($mm->mes == 6)
							  <td>Junio</td>
							   @elseif ($mm->mes == 7)
							    <td>Julio</td>
							    @elseif ($mm->mes == 8)
							    <td>Agosto</td>
							     @elseif ($mm->mes == 9)
							        <td>Septiembre</td>
							      @elseif ($mm->mes == 10)
							      <td>Octubre</td>
							       @elseif ($mm->mes == 11)
							       <td>Noviembre</td>
							        @elseif ($mm->mes == 12)
							        <td>Diciembre</td>


							@endif	    
							
							<td>
								{{$mm->receitaLiquida}}
							</td>
							<td>
								<td>{{ $datoss[1][0]->plata}}</td>
							</td>
							
							
						</tr>

						@endif
						

						@endforeach
						@foreach ($toti as $to)
						@if ($sa->nom == $to->per)
						<tr> <td></td><td><h6>{{$to->total}} </h6> </td><td></td></tr>
						@endif	 

						@endforeach
					</tbody>
					

				</table>
				@endforeach
				
		
	</div>
@endsection
					
